# Local ROS2 Foxy Preparation Rules



This workspace is being prepared locally without a real Unitree robot connected.



## Safety



- Do not publish to `/cmd_vel`.

- Do not run `cmd_vel_node`.

- Do not launch with `enable_cmd_vel:=true`.

- Do not run real robot movement commands.

- Use real launch only for syntax/dependency checks with:

  `enable_cmd_vel:=false enable_camera:=false enable_april:=false`

- Real movement is gated. Do not start movement-capable paths unless the user
  explicitly approves field movement and provides:

  `robot_ack:=I_UNDERSTAND_THIS_CAN_MOVE_THE_REAL_ROBOT`

- `cmd_vel_node` must refuse to initialize Unitree SDK without the exact
  `robot_ack` above.

- `main.py` and `april_localizer.py` must keep `/cmd_vel` publishing disabled by
  default. AprilTag scan/rotate mode is movement-capable and must stay disabled
  unless the same movement gate is armed.



## Scope



Focus on:

- workspace structure

- ROS2 Foxy environment

- dependency checks

- `colcon build`

- package executable checks

- launch syntax checks

- simulation/fake testing if available

- identifying hardcoded config before field testing



## Simulation Notes



- `sim.launch.py` is intended for local software checks with no real robot connected.

- Keep local simulation launches safe by default:

  `enable_unitree_bridge:=false enable_april:=false enable_stream:=false enable_init_pose:=false`

- When testing the Unitree fake bridge in simulation, use:

  `enable_unitree_bridge:=true enable_april:=false enable_stream:=false enable_init_pose:=false`

- TurtleBot3/Gazebo publishes the source topics as `/joint_states`, `/odom`, and `/imu`.

- `gazebo_convert` internally expects `/sim_joint_states`, `/sim_odom`, and `/sim_imu`, so `sim.launch.py` must remap:

  - `/sim_joint_states` -> `/joint_states`

  - `/sim_odom` -> `/odom`

  - `/sim_imu` -> `/imu`

- If `/lf/lowstate` exists but `ros2 topic hz /lf/lowstate` reports no data, first check that `/joint_states`, `/odom`, and `/imu` are publishing and that the remaps above are present.

- TurtleBot3/Gazebo publishes lidar as LaserScan on `/scan`, not PointCloud2. The Go2 pipeline expects PointCloud2 on `/utlidar/cloud`, and `go2w_read` republishes that as `/pointcloud`.

- `scan_to_pointcloud` exists for local simulation only. With `enable_unitree_bridge:=true`, `sim.launch.py` starts:

  `/scan` -> `scan_to_pointcloud` -> `/utlidar/cloud` -> `go2w_read` -> `/pointcloud`

- Keep `enable_pc2scan:=false` for the normal TurtleBot3 simulation path. Turning it on converts `/utlidar/cloud` back to `/scan`, which is useful for real/fake PointCloud tests but can create a confusing scan/cloud loop in this sim setup.

- For fake Unitree bridge validation, check these rates after launching sim:

  - `ros2 topic hz /lf/lowstate`

  - `ros2 topic hz /lf/sportmodestate`

  - `ros2 topic hz /utlidar/cloud`

  - `ros2 topic hz /pointcloud`

  - `ros2 topic hz /odom`

  - `ros2 topic hz /imu/data`

- `go2_control local_check` is the preferred read-only smoke test once sim is running. Run it after sourcing the workspace:

  `ros2 run go2_control local_check`

- The workspace also has a helper script:

  `/home/sys20/projects/systonic-2307/Systronic/scripts/local_sim_check.sh`

  It sources ROS Foxy and the workspace, then runs `go2_control local_check`.

- `local_check` only subscribes/inspects graph state. It must not publish `/cmd_vel` or send robot commands. It checks core nodes, required simulated topics, `/map` with transient-local QoS, and warns if non-Gazebo `/cmd_vel` publishers are present.

- If a sandboxed tool run fails with `getifaddrs: Operation not permitted`, that is a ROS DDS discovery permission issue in the tool sandbox. Ask the user to run the checker in their terminal, or rerun with approved network-interface access.

- Do not press RViz `Nav2 Goal` during safety-only checks; Nav2 goals can publish `/cmd_vel` in simulation.

- Real robot field checks are documented in:

  `/home/sys20/projects/systonic-2307/Systronic/src/go2_control/REAL_ROBOT_FIELD_CHECKLIST.md`



Keep edits scoped to:

- `src/go2_control`

- `src/go2_interfaces`



Ask before:

- installing dependencies

- deleting files

- changing launch behavior

- changing network or robot movement behavior
