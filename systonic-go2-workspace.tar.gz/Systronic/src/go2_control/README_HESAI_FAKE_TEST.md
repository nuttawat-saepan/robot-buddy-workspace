# Hesai XT16 Fake LiDAR Test

This workflow tests the LiDAR-to-costmap path locally without a real Hesai
LiDAR, Unitree ROS network, or robot motion commands.

Do not run `cmd_vel_node` for this test.

## 1. Build

```bash
cd /home/sys20/projects/systonic-2307/Systronic
source /opt/ros/foxy/setup.bash
colcon build --packages-select go2_interfaces go2_control
source install/setup.bash
```

## 2. Run Fake Hesai And LaserScan

Terminal 1:

```bash
cd /home/sys20/projects/systonic-2307/Systronic
source /opt/ros/foxy/setup.bash
source install/setup.bash
ros2 launch go2_control hesai_fake_scan.launch.py
```

This starts:

```text
fake_hesai_xt16 -> /lidar_points
static TF base_link -> hesai_lidar
pointcloud_to_laserscan -> /scan
```

Expected checks:

```bash
ros2 topic hz /lidar_points
ros2 topic hz /scan
```

Both should be near 10 Hz.

## 3. Run Costmap-Only Test

Terminal 2:

```bash
cd /home/sys20/projects/systonic-2307/Systronic
source /opt/ros/foxy/setup.bash
source install/setup.bash
ros2 launch go2_control costmap_scan_test.launch.py
```

This starts only:

```text
map_server
standalone costmap
robot_state_publisher
static TF map -> odom
static TF odom -> base_link
rviz2
```

It does not start:

```text
cmd_vel_node
controller_server
planner_server
bt_navigator
go2w_read
camera
april_localizer
```

Expected checks:

```bash
ros2 topic list | grep cmd_vel
ros2 service call /costmap/costmap/get_state lifecycle_msgs/srv/GetState {}
ros2 topic hz /costmap/costmap_raw
```

`grep cmd_vel` should print nothing. The costmap state should be `active`.

## 4. RViz

Use these displays:

```text
Fixed Frame: map
TF
Map: /map
LaserScan: /scan
Costmap: /costmap/costmap_raw
```

For `/map`, set:

```text
Reliability Policy: Reliable
Durability Policy: Transient Local
```

## 5. Real Hesai Swap

When the real Hesai XT16 is available, stop `hesai_fake_scan.launch.py` and run
the real Hesai driver so it publishes:

```text
/lidar_points
frame_id: hesai_lidar
```

Then run:

```bash
ros2 launch go2_control hesai_scan.launch.py
```

The downstream path remains:

```text
/lidar_points -> pointcloud_to_laserscan -> /scan -> costmap
```

Update the static transform in `hesai_scan.launch.py` to match the real sensor
mounting position before field testing.

## 6. Simulation-Only Drive Smoke Test

This test uses a copied TurtleBot3 Gazebo model whose diff-drive plugin listens
to `/sim_cmd_vel`, not `/cmd_vel`.

Terminal:

```bash
cd /home/sys20/projects/systonic-2307/Systronic
source /opt/ros/foxy/setup.bash
source install/setup.bash
ros2 launch go2_control sim_safe_drive_test.launch.py
```

This starts Gazebo only. It does not publish movement commands by default.

To send a short sim-only command:

```bash
ros2 launch go2_control sim_safe_drive_test.launch.py enable_drive:=true
```

The default command publishes `/sim_cmd_vel` for 3 seconds:

```text
linear_x: 0.08
angular_z: 0.0
duration: 3.0
```

Check that `/cmd_vel` is not present:

```bash
ros2 topic list | grep cmd_vel
```

Expected result:

```text
/sim_cmd_vel
```

There should be no root `/cmd_vel` topic.
