# Hesai XT16 + Go2 Handoff

Use this note to resume field integration work safely.

## Safety

- Do not publish `/cmd_vel`.
- Do not run `cmd_vel_node`.
- Do not launch with `enable_cmd_vel:=true`.
- Do not run real robot movement commands.
- Start field testing with LiDAR + costmap only.

## Workspaces

```bash
source /opt/ros/foxy/setup.bash
source ~/hesai_ws/install/setup.bash
source ~/projects/systonic-2307/Systronic/install/setup.bash
```

Main workspace:

```text
~/projects/systonic-2307/Systronic
```

Hesai workspace:

```text
~/hesai_ws
```

## Verified

- `hesai_ros_driver` builds in `~/hesai_ws`.
- `ros2 pkg executables hesai_ros_driver` shows `hesai_ros_driver_node`.
- Fake Hesai pipeline passed:

```text
/lidar_points -> /scan -> /costmap/costmap_raw -> RViz
```

- Expected real Hesai output:

```text
topic: /lidar_points
frame_id: hesai_lidar
```

## Key Files

```text
src/go2_control/HESAI_GO2_FIELD_CHECKLIST.md
src/go2_control/config/hesai_xt16_live.template.yaml
src/go2_control/pc2scan_hesai.yaml
src/go2_control/launch/hesai_scan.launch.py
src/go2_control/launch/costmap_scan_test.launch.py
```

## Unitree Messages

`unitree_go` and `unitree_api` are now copied into the Systronic workspace and
build successfully.

```bash
python3 -c "from unitree_go.msg import LowState, SportModeState; print('unitree_go ok')"
```

Expected result:

```text
unitree_go ok
```

The Unitree packages were patched to make `rosidl_generator_dds_idl` optional,
because it is not installed in this ROS 2 Foxy environment. This keeps normal
ROS 2 message generation available for `go2w_read`.

`go2w_read` has been import-checked only; it has not been run against a real
robot.

## Field Test Order

1. Source overlay.
2. Check Hesai network:

```bash
ip addr
ping <HESAI_IP>
```

3. Copy `hesai_xt16_live.template.yaml` to a field config and replace:

```text
REPLACE_WITH_HESAI_IP
```

4. Run Hesai driver with `source_type: 1` only after LiDAR/network are connected.
5. Verify:

```bash
ros2 topic hz /lidar_points
ros2 topic echo /lidar_points
```

6. Run downstream scan conversion:

```bash
ros2 launch go2_control hesai_scan.launch.py
```

7. Verify:

```bash
ros2 topic hz /scan
ros2 run tf2_ros tf2_echo base_link hesai_lidar
```

8. Run costmap-only:

```bash
ros2 launch go2_control costmap_scan_test.launch.py
```

9. Verify safety and costmap:

```bash
ros2 topic list | grep cmd_vel
ros2 service call /costmap/costmap/get_state lifecycle_msgs/srv/GetState {}
ros2 topic hz /costmap/costmap_raw
```

Expected:

```text
No root /cmd_vel topic
costmap state is active
/costmap/costmap_raw publishes
```

10. Do not proceed to movement until Go2 odom/TF and safety checks pass.
